#ifndef CSOXR_VERSION_H_
#define CSOXR_VERSION_H_

#ifdef __cplusplus
extern "C" {
#endif

const char * libsoxr_version();

#ifdef __cplusplus
}
#endif

#endif /* CSOXR_VERSION_H_ */
