// versioning for bundled libsoxr

#include "csoxr_version.h"

const char * libsoxr_version() {
    return "0.1.3-11-gedbdb40";
}
