```{toctree}
---
maxdepth: 2
---
soxr.md
```

```{include} ../README.md
```
