/* SoX Resampler Library      Copyright (c) 2007-16 robs@users.sourceforge.net
 * Licence for this file: LGPL v2.1                  See LICENCE for details. */

#define PFFFT_DOUBLE 1

#include "util64s.h"

#include "util-simd.c"
