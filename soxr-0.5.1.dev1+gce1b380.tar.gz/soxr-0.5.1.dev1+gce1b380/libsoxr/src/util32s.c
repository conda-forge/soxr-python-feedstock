/* SoX Resampler Library      Copyright (c) 2007-16 robs@users.sourceforge.net
 * Licence for this file: LGPL v2.1                  See LICENCE for details. */

#define PFFFT_DOUBLE 0

#include "util32s.h"

#include "util-simd.c"
