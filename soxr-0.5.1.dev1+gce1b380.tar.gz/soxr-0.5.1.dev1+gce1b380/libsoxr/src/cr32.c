/* SoX Resampler Library      Copyright (c) 2007-16 robs@users.sourceforge.net
 * Licence for this file: LGPL v2.1                  See LICENCE for details. */

#define RATE_CB    _soxr_rate32_cb
#define CORE_STR   "cr32"

#define CORE_TYPE  0
#include "cr-core.c"
